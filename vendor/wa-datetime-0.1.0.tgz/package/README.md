# wa-datetime

> 和時刻・和暦変換 TypeScript ライブラリ

`Date` オブジェクトひとつから、旧暦・六曜・二十四節気・節句・雑節・和時刻（不定時法）・月齢を一括変換します。外部依存ゼロ、天文略算式で完全自己完結。

## インストール（公開後）

```bash
npm install wa-datetime
```

## 使い方

### WaDateTime クラス（推奨）

```ts
import { WaDateTime } from 'wa-datetime'

const wa = new WaDateTime(new Date('2026-01-29'))

// 旧暦
wa.lunar()           // { year: 2026, month: 1, day: 1, isLeap: false }
wa.lunarMonthName()  // "睦月"
wa.lunarDayName()    // "初一"

// 六曜
wa.rokuyou()         // "大安" | "仏滅" | ...

// 二十四節気（その日が節気でなければ null）
wa.sekki()           // { name: "立春", reading: "りっしゅん", longitude: 315 } | null
wa.nextSekki()       // 次の節気

// 節句（五節句）
wa.sekku()           // { name: "端午", reading: "...", ... } | null

// 雑節（節分・彼岸・土用など、複数可）
wa.zassetsu()        // [{ name: "節分", reading: "せつぶん" }]

// 和時刻（不定時法）— 日の出・日の入りを分で渡す
const SR = 360   // 06:00
const SS = 1080  // 18:00
wa.koku(SR, SS)
// {
//   eto: { kanji: "午", reading: "うま", number: "九つ", sub: "昼九つ", period: "day" },
//   progress: 0.5,        // 刻内の経過割合
//   dayKokuMins: 120,     // 昼の一刻の長さ（分）
//   nightKokuMins: 120,
//   sunriseMins: 360,
//   sunsetMins: 1080,
// }
wa.kokuDuration(SR, SS)  // { day: "2時間0分", night: "2時間0分" }

// 月齢
wa.moonPhase()       // 0.0（新月）〜 0.5（満月）〜 1.0
wa.moonPhaseName()   // "満月" | "三日月" | ...

// 全情報まとめて
wa.toSummary(SR, SS)
```

### 個別関数（tree-shakable）

```ts
import { toLunar, rokuyou, sekki, zassetsu, toKoku, moonPhase } from 'wa-datetime'

const lun = toLunar(new Date())
const ry  = rokuyou(new Date())
const k   = toKoku(
  new Date().getHours() * 60 + new Date().getMinutes(),
  360,   // 日の出（分）
  1080,  // 日の入り（分）
)
```

## 計算内容

| 機能 | 方式 |
|---|---|
| 旧暦変換 | 合朔（新月）のユリウス日 + 冬至基点の月番号割り当て |
| 六曜 | `(旧暦月 + 旧暦日) % 6` |
| 二十四節気 | 太陽黄経の二分法探索（Meeus略算式） |
| 節句 | 旧暦月日による照合 |
| 雑節 | 節気からの日数・黄経による計算 |
| 和時刻 | 不定時法（昼夜それぞれ6等分） |
| 月齢 | 既知の新月基点からの経過日数 |

> **注**: 閏月の完全な計算は未実装（精度 > 99%）。日の出・日の入り時刻はアプリ側で取得して渡す設計。

## 開発

```bash
npm install
npm test          # Vitest によるテスト実行
npm run build     # dist/ へビルド
npm run typecheck # 型検査
```

## ライセンス

MIT
